package com.example.yemekbitirmeodevi.data.entity

class SepetYemekler {
}