package com.example.yemekbitirmeodevi.di

class HiltApplication {
}