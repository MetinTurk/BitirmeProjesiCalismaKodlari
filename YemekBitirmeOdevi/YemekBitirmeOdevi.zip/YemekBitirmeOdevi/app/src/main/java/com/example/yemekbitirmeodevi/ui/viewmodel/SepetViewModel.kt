package com.example.yemekbitirmeodevi.ui.viewmodel

class SepetViewModel {
}