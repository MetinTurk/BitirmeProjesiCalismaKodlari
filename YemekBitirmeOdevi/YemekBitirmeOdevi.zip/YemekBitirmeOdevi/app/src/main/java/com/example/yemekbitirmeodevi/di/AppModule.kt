package com.example.yemekbitirmeodevi.di

class AppModule {
}