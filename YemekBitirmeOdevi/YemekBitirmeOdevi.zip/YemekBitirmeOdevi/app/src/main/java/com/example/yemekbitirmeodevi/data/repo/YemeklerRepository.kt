package com.example.yemekbitirmeodevi.data.repo

class YemeklerRepository {
}