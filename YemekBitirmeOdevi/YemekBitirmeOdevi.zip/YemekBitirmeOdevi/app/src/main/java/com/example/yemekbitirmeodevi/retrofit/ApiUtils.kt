package com.example.yemekbitirmeodevi.retrofit

class ApiUtils {
}