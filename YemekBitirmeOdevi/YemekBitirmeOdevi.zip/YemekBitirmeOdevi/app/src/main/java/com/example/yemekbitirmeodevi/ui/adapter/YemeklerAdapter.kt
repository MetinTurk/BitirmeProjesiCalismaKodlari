package com.example.yemekbitirmeodevi.ui.adapter

class YemeklerAdapter {
}