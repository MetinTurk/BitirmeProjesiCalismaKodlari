package com.example.yemekbitirmeodevi.retrofit

interface YemeklerDaoInterface {
}