package com.example.yemekbitirmeodevi.retrofit

class RetrofitClient {
}